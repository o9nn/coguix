;;; GNU Guix --- Functional package management for GNU
;;; Copyright © 2019 Guillaume Le Vaillant <glv@posteo.net>
;;; Copyright © 2020, 2021 Tobias Geerinckx-Rice <me@tobias.gr>
;;;
;;; This file is part of GNU Guix.
;;;
;;; GNU Guix is free software; you can redistribute it and/or modify it
;;; under the terms of the GNU General Public License as published by
;;; the Free Software Foundation; either version 3 of the License, or (at
;;; your option) any later version.
;;;
;;; GNU Guix is distributed in the hope that it will be useful, but
;;; WITHOUT ANY WARRANTY; without even the implied warranty of
;;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;;; GNU General Public License for more details.
;;;
;;; You should have received a copy of the GNU General Public License
;;; along with GNU Guix.  If not, see <http://www.gnu.org/licenses/>.

(define-module (gnu packages genealogy)
  #:use-module (guix build-system pyproject)
  #:use-module (guix git-download)
  #:use-module ((guix licenses) #:prefix license:)
  #:use-module (guix gexp)
  #:use-module (guix packages)
  #:use-module (gnu packages base)
  #:use-module (gnu packages bash)
  #:use-module (gnu packages fonts)
  #:use-module (gnu packages freedesktop)
  #:use-module (gnu packages geo)
  #:use-module (gnu packages gettext)
  #:use-module (gnu packages ghostscript)
  #:use-module (gnu packages glib)
  #:use-module (gnu packages gnome)
  #:use-module (gnu packages graphviz)
  #:use-module (gnu packages gtk)
  #:use-module (gnu packages python)
  #:use-module (gnu packages python-build)
  #:use-module (gnu packages python-xyz)
  #:use-module (gnu packages sqlite)
  #:use-module (gnu packages version-control)
  #:use-module (gnu packages xml))

(define-public gramps
  (package
    (name "gramps")
    (version "5.2.3")
    (source
     (origin
       (method git-fetch)
       (uri (git-reference
             (url "https://github.com/gramps-project/gramps")
             (commit (string-append "v" version))))
       (file-name (git-file-name name version))
       (sha256
        (base32 "1gzhi5hxpgc6pxs40xsxf67hndjifnfhm89s3ly68c70x83qmwhd"))))
    (build-system pyproject-build-system)
    (arguments
     (list
      #:imported-modules
      `((guix build glib-or-gtk-build-system)
        ,@%pyproject-build-system-modules)
      #:modules
      `((ice-9 match)
        (srfi srfi-1)
        (guix build pyproject-build-system)
        ((guix build glib-or-gtk-build-system) #:prefix glib-or-gtk:)
        (guix build utils))
      #:phases
      #~(modify-phases %standard-phases
          (add-before 'check 'prepare-tests
            (lambda _
              (setenv "HOME" (getenv "TMPDIR"))
              ;; Presence of .git directory is used to determine whether this
              ;; is a final installation.  Without it, tests fail to determine
              ;; resource path.
              (mkdir ".git")
              ;; Test is failing
              (delete-file "gramps/gen/utils/test/file_test.py")))
          (add-before 'wrap 'wrap-with-GI_TYPELIB_PATH
            (lambda* (#:key inputs #:allow-other-keys)
              (wrap-program (string-append #$output "/bin/gramps")
                `("GI_TYPELIB_PATH" ":" prefix
                  ,(filter-map
                    (match-lambda
                      ((output . directory)
                       (let ((girepodir (string-append
                                         directory
                                         "/lib/girepository-1.0")))
                         (and (file-exists? girepodir)
                              girepodir))))
                    inputs)))))
          (add-after 'wrap 'glib-or-gtk-wrap
            (assoc-ref glib-or-gtk:%standard-phases 'glib-or-gtk-wrap)))))
    (native-inputs
     (list gettext-minimal intltool
           glibc-utf8-locales ;for one test
           python-setuptools))
    (inputs
     (list bash-minimal
           cairo
           font-gnu-freefont
           geocode-glib
           gexiv2
           ghostscript
           gobject-introspection
           gtk+
           gtkspell3
           graphviz
           (librsvg-for-system)
           osm-gps-map
           pango
           python-bsddb3
           python-jsonschema
           python-lxml
           python-pillow
           python-pycairo
           python-pygobject
           python-pyicu
           rcs
           sqlite
           xdg-utils))
    (home-page "https://gramps-project.org")
    (synopsis "Genealogical research software")
    (description
     "Gramps is a free software project and community striving to produce
a genealogy program that is both intuitive for hobbyists and feature-complete
for professional genealogists.")
    (license license:gpl2+)))
